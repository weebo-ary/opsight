import React from 'react'

function support() {
  return (
    <div>support</div>
  )
}

export default support