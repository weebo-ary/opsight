import Solutions from '@/components/Solutions'
import React from 'react'
// import oee_Dashboard from "../../media/oee_Dashboard.jpg"

const Performance_monitoring = () => {
  const data = {
    headImage: "/Performance_Monitoring_heading1.png",
    headImageMobile: "/Performance_Monitoring_heading_mobile1.png",
    contentImage: "/perfomnace_monitoring.svg",
    heading: "Performance Monitoring (OEE)",
    desc: "Continuous Monitoring and Immediate Data Analysis for Real-time Insights.",
    bullets: [
      {
        icon: "fa-solid fa-rotate",
        heading: "Real-Time Data Tracking",
        desc: "Our OEE system provides real-time tracking of machine performance, allowing you to monitor production data as it happens."
      },
      {
        icon: "fa-regular fa-calendar-days",
        heading: "Historical Data Analysis",
        desc: "Analyze historical data for trends, informing decisions, streamlining workflows, and boosting long-term performance in manufacturing processes."
      },
      {
        icon: "fa-solid fa-table-columns",
        heading: "Visual Dashboard & Reporting",
        desc: "Access user-friendly OEE dashboard, generate custom reports for easy performance insights sharing with your team and stakeholders."
      },
      {
        icon: "fa-solid fa-bug",
        heading: "Root Cause Analysis",
        desc: "Perform in-depth root cause analysis on performance issues to address underlying problems and prevent recurring issues, fostering continuous improvement."
      },
    ]
  };
  return (
    <>
       <Solutions data={data}/>
    </>
  )
}

export default Performance_monitoring