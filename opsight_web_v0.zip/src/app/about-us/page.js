"use client";

import React, { useState } from "react";
// import Image from "next/image";
import "@/app/about-us/about.css";
import AboutProfile from "@/components/AboutProfile";
import AboutVision from "@/components/AboutVision";
import AboutMission from "@/components/AboutMision";
import AboutTeam from "@/components/AboutTeam";
import NumberCounter from "@/components/NumberCounter";

// import bannergif from "@/media/banner.gif";

const About = () => {
  const [activeTab, setActiveTab] = useState("Profile");

  const tabClickHandler = (tabName) => {
    setActiveTab(tabName);
  };

  return (
    <>
      <div className="overflow-hidden">
        {/* <div className="about-banner flex items-center justify-center">
          <div className="w-8/12 h-full flex items-center justify-between">
            <h1 className="text-5xl tracking-widest font-semibold text-orange-300">
              #About-Us
            </h1>
            <Image className="about-bannergif" src={bannergif} />
          </div>
        </div> */}
        {/* <ul className="my-10 mx-44 flex flex-wrap text-sm font-medium text-center text-gray-500 border-b">
          <li className="mr-2">
            <a
              onClick={() => tabClickHandler("Profile")}
              href="#"
              // inline-block p-4 text-gray-950 font-bold rounded-t-lg
              aria-current="page"
              className={`cool-link inline-block p-4 tracking-wide text-gray-600 font-bold rounded-t-lg ${
                activeTab === "Profile" ? "active" : ""
              }`}
            >
              Our Profile
            </a>
          </li>
          <li className="mr-2">
            <a
              onClick={() => tabClickHandler("Vision")}
              href="#"
              className={`cool-link inline-block p-4 tracking-wide text-gray-600 font-bold rounded-t-lg ${
                activeTab === "Vision" ? "active" : ""
              }`}
            >
              Vision
            </a>
          </li>
          <li className="mr-2">
            <a
              onClick={() => tabClickHandler("Mission")}
              href="#"
              className={`cool-link inline-block p-4 tracking-wide text-gray-600 font-bold rounded-t-lg ${
                activeTab === "Mission" ? "active" : ""
              }`}
            >
              Mission
            </a>
          </li>
          <li className="mr-2">
            <a
              onClick={() => tabClickHandler("Team")}
              href="#"
              className={`cool-link inline-block p-4 tracking-wide text-gray-600 font-bold rounded-t-lg ${
                activeTab === "Team" ? "active" : ""
              }`}
            >
              Team Details
            </a>
          </li>
        </ul> */}

        {/* <div className="content">
          {activeTab === "Profile" && <AboutProfile />}
          {activeTab === "Vision" && <AboutVision />}
          {activeTab === "Mission" && <AboutMission />}
          {activeTab === "Team" && <AboutTeam />}
        </div> */}
        <AboutProfile />
        <AboutVision />
        <AboutMission />
        {/* <NumberCounter /> */}
        <AboutTeam />
      </div>
    </>
  );
};

export default About;
