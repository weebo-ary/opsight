"use client";
import React, { useState } from "react";
import "../../components/css/contact.css";
// import contactImg from "../../media/contact.png";
import Image from "next/image";
import Spinner from "@/components/Spinner";

const Contact = () => {
  const [isLoading, setIsLoading] = useState(false);
  const submitForm = (e) => {
    e.preventDefault();
    setIsLoading(true);

    console.log(e.target);
    const formdData = new FormData(e.target);
    fetch("https://api.apispreadsheets.com/data/66y5X9hsZBU5zYyC", {
      method: "POST",
      body: formdData,
    })
      .then(function (response) {
        if (response.ok) {
          alert(
            "Thank you for contacting us ! Our team will get in touch with you shortly !"
          );
          setIsLoading(false);
          e.target.reset();
        } else {
          console.log(response);
          setIsLoading(false);

          // alert("There was an error :(");
        }
      })
      .catch(function (error) {
        console.log("Error:", error);
        setIsLoading(false);
      });
  };

  return (
    <div className="contactSecion">
      <div className="sub-heading">Connect with us</div>
      <div className="description">
        Feel free to contact us with your inquiries, feedback, or any assistance
        you may need. We value your feedback and are here to assist with any
        inquiries or support you may require.{" "}
      </div>
      <div className="contactGrid">
        <div className="left">
          {/* <Image
          src={"/contact.png"}
          className="contactImg"
          width={500}
          height={500}
        /> */}
          <div className="detailsValue mt-4">
            <i className="fa-solid fa-envelope mr-1"></i>
            <a href="mailto:connect@opsight.ai">
              <div className="detailsSubHeading"> Email</div>
              <span>connect@opsight.ai</span>
            </a>
          </div>
          <div className="detailsValue mt-4">
            <i className="fa-brands fa-linkedin mr-1"></i>
            <a href="https://www.linkedin.com/company/opsight-ai-pvt-ltd/">
              <div className="detailsSubHeading"> Linkedin</div>
              <span>Opsight AI Pvt. Ltd.</span>
            </a>
          </div>
          <div className="detailsValue mt-4">
            <i className="fa-solid fa-location-pin mr-1"></i>
            <div>
              <div className="detailsSubHeading">Bhopal Office</div>
              <span>A3/603, Priyadarshini Adhishthan Bawadia Kalan, Bhopal (M.P.),
              462026</span>
            </div>
          </div>
        </div>
        <div className="right">
          <form onSubmit={submitForm} className="contactForm">
            <h3>Send Message</h3>
            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-6 group">
                <input
                  type="text"
                  name="first_name"
                  id="floating_first_name"
                  className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-gray dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                  placeholder=" "
                  required
                />
                <label
                  htmlFor="floating_first_name"
                  className="peer-focus:font-medium absolute text-sm text-gray-900 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                >
                  First name
                </label>
              </div>
              <div className="relative z-0 w-full mb-6 group">
                <input
                  type="text"
                  name="last_name"
                  id="floating_last_name"
                  className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-gray dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                  placeholder=" "
                  required
                />
                <label
                  htmlFor="floating_last_name"
                  className="peer-focus:font-medium absolute text-sm text-gray-900 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
                >
                  Last name
                </label>
              </div>
            </div>

            <div className="relative z-0 w-full mb-6 group">
              <input
                type="email"
                name="email"
                id="floating_email"
                className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-gray dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                placeholder=" "
                required
              />
              <label
                htmlFor="floating_email"
                className="peer-focus:font-medium absolute text-sm text-gray-900 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
              >
                Email address
              </label>
            </div>

            <div className="relative z-0 w-full mb-6 group">
              <textarea
                name="message"
                id="floating_password"
                className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-gray dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
                placeholder=" "
                required
              ></textarea>
              <label
                htmlFor="floating_password"
                className="peer-focus:font-medium absolute text-sm text-gray-900 dark:text-gray-500 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
              >
                Message
              </label>
            </div>
            <button type="submit" className="contactUsButton">
              Send
            </button>
            {isLoading && <Spinner />}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
