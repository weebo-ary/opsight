'use client';
import Herosection from "@/components/Herosection";
import NavBar from "@/components/Navbar";
import Faq from "@/components/Faq";
import React, { useEffect, useRef } from "react";
import OurProducts from "@/components/OurProducts";
import SolutionEffect from "@/components/SolutionEffect";
import Unique from "@/components/Unique";
import Partners from "@/components/Partners";

const HomePage = () => {

  const scrollContainer = useRef(null)

  // useEffect(() => {

  //   (
  //     async () => {
  //       const LocomotiveScroll = (await import ("locomotive-scroll")).default;
  //       const locomotiveScroll = new LocomotiveScroll();
  //       // const locomotiveScroll = new LocomotiveScroll({
  //       //   el: scrollContainer.current,
  //       //   smooth: true,
  //       // })
  //     }
  //   )()
    
  // }, [])
  

  return (
    <div className="pb-0">
      <Herosection />
      <OurProducts />

      {/* <Unique /> */}
      {/* <div className="banner">
        <div className="bannerTitle sub-heading">What makes us Unique?</div>
        <div className="bannerDesc">
          Our data platform is being purpose-built to utilise advanced machine
          learning algorithms to identify patterns, detect anomalies and offer
          predictive insights on real-time production data
        </div>
      </div> */}
      <Partners />
      <SolutionEffect />
      <Faq />
    </div>
  );
};

export default HomePage;
