import React from "react";
import Solutions from "@/components/Solutions";
// import Customised_Solutions_Img from "../../media/Customised_Solutions.jpg"

const Customised_Solutions = () => {
  const data = {
    headImage: "/Customised_Solutions_heading.jpg",
    headImageMobile: "/Customised_Solutions_heading_mobile.jpg",
    contentImage: "/Customised_Solutions.svg",
    heading: "Customised Solutions",
    desc: "Your Vision, Our Precision: Custom Solutions Redefined!",
    bullets: [
      {
        icon: "fa-solid fa-check",
        heading: "Precision and Efficiency",
        desc: "Our customized solutions seamlessly integrate with your infrastructure, ensuring smooth and efficient operations, free from disruptions or complications."
      },
      {
        icon: "fa-solid fa-solid fa-chart-line",
        heading: "Improved Productivity",
        desc: "Tailored solutions optimize workflow with intuitive tools, enhancing productivity and minimizing learning curve challenges."
      },
      {
        icon: "fa-solid fa-arrow-up-right-dots",
        icon: "fa-solid fa-arrow-up-right-dots",
        heading: "Scalability and Flexibility",
        desc: "Our solutions are designed to scale with your business, providing flexibility to adapt to evolving needs and accommodate growth seamlessly."
      },
      {
        icon: "fa-solid fa-chalkboard-user",
        heading: "Comprehensive Support and Training",
        desc: "We offer comprehensive support and training to ensure a smooth transition to customized solutions, empowering your team to make the most of the tailored features."
      },
    ]
  };
  return (
    <>
      <Solutions data={data} />
    </>
  );
};

export default Customised_Solutions;
