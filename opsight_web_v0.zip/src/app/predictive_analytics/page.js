import React from 'react'
import Solutions from '@/components/Solutions'
// import Predictive_Analytics_Img from "../../media/Predictive_Analytics.jpg"

const PredictiveAnalysis = () => {
  const data = {
    headImage: "/Predictive_Analytics_heading.png",
    headImageMobile: "/Predictive_Analytics_heading_mobile.png",
    contentImage: "/Predictive_Analytics_2.svg",
    heading: "Predictive Analytics",
    desc: "Unlock the Future with Predictive Analytics: Where Data Meets Destiny",
    bullets: [
      {
        icon: "fa-solid fa-tv",
        heading: "Asset Performance Monitoring",
        desc: "Predictive analytics in IIoT enables real-time tracking of asset performance, allowing for proactive maintenance and increased asset utilization."
      },
      {
        icon: "fa-solid fa-magnifying-glass-chart",
        heading: "Quality Control and Process Optimization",
        desc: "Quality control thrives with IIoT predictive analytics, fine-tuning processes for cost-efficiency and consistently superior outcomes."
      },
      {
        icon: "fa-solid fa-money-check-dollar",
        heading: "Cost Savings",
        desc: "Proactive maintenance and streamlined operations save costs by preventing unnecessary repairs and resource wastage."
      },
      {
        icon: "fa-solid fa-user",
        heading: "Customer Relationship Management (CRM)",
        desc: "Predictive analytics can analyze customer data to predict behavior, improve customer satisfaction, and personalize marketing efforts."
      },
    ]
  };
      return (
        <>
           <Solutions data={data}/>
        </>
      )
}

export default PredictiveAnalysis
