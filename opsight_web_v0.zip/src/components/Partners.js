import "./css/partners.css";
import Image from "next/image";


import gsap from "gsap"
import {ScrollTrigger} from "gsap/ScrollTrigger"
import {useLayoutEffect, useRef} from "react"



const Partners = () => {

  const headingDiv = useRef(null)
  const div1 = useRef(null)
  const div2 = useRef(null)
  const div3 = useRef(null)
  const div4 = useRef(null)

  useLayoutEffect(() => {
    
    gsap.registerPlugin(ScrollTrigger);

    const t1 = gsap.timeline({
      scrollTrigger: {
        trigger: headingDiv.current,
        start: "top 70%",
        end: "top 50%",
        toggleActions: "restart none none reset",
        // markers: true,
        // scrub: true,
      },
    })

    t1.to(div1.current, {
      y: 0,
        opacity:1,
        duration: 0.5,
    })
    .to(div2.current, {
      y: 0,
        opacity: 1,
        duration: 0.5,
    }, "-=0.1")
    .to(div3.current, {
      y: 0,
        opacity: 1,
        duration: 0.5,
    }, "-=0.1")
    .to(div4.current, {
      y: 0,
        opacity: 1,
        duration: 0.5,
    }, "-=0.1")    
  
    
  }, [])




  return (
    <div ref={headingDiv} className="partnersSection">
      

      {/* <Image src="/corner1.png" height={500} width={500} className="cornerLeft corner" /> */}
      {/* <Image src="/corner1.png" height={500} width={500} className="cornerRight corner" /> */}
      <div className="partnersHead">Recognised by</div>
      {/* <div className="partnersSubHead">
        Our recognized status is a testament to our commitment to pioneering
        solutions and pushing the boundaries of what's possible.
      </div> */}
      <div className="partnersLogoFlex">
        <div ref={div1} className="logoDiv translate-y-5 opacity-0">
          <Image
            src="/startup_india.png"
            className="partnersLogo startupIndia"
            width={900}
            height={900}
          />
          <div className="logoTooltip">
            Fuelled by innovation, proudly endorsed by Startup India. Unleash
            your potential with our recognized solution.
          </div>
        </div>
        <div ref={div2} className="logoDiv translate-y-5 opacity-0">
          <Image
            src="/mp_startup.png"
            className="partnersLogo mp_startup"
            width={900}
            height={900}
          />
          <div className="logoTooltip">
            Embark on a journey of innovation with confidence, as we proudly
            carry the recognition of MP Startup. Elevate your endeavours with
            Opsight AI.
          </div>
        </div>
        <div ref={div3} className="logoDiv translate-y-5 opacity-0">
          <Image
            src="/mathworks.svg"
            className="partnersLogo mathworks"
            width={900}
            height={900}
          />
          <div className="logoTooltip">
            Innovation thrives with support from MathWorks Accelerator program.
          </div>
        </div>
        <div ref={div4} className="logoDiv translate-y-5 opacity-0">
          <Image
            src="/lnct2.png"
            className="partnersLogo lnct"
            width={900}
            height={900}
          />
          <div className="logoTooltip">
            Powered by the spirit of education and innovation, proudly incubated
            by LNCT College. Transforming ideas into reality.
          </div>
        </div>
      </div>
    </div>
  );
};

export default Partners;
