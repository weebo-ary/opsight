"use client";
import React, { useRef, useState } from "react";
import "./css/navbar.css";
import Link from "next/link";

const Navbar = () => {
  const chevronRef = useRef(null);
  const navbarRef = useRef(null);
  const [isSublinksOpened, setIsSublinksOpened] = useState(false);
  const [isNavbarOpened, setIsNavbarOpened] = useState(false);
  const toggleLinks = () => {
    if (isSublinksOpened) {
      chevronRef.current.style.transform = "rotate(0deg)";
    } else {
      chevronRef.current.style.transform = "rotate(180deg)";
    }
    setIsSublinksOpened(!isSublinksOpened);
  };

  const toggleNav = () => {
    console.log(navbarRef.current.style.transform);
    if (!isNavbarOpened) {
      setIsNavbarOpened(true);
      navbarRef.current.style.transform = "translate(0, 0%)";
    } else {
      setIsNavbarOpened(false);
      navbarRef.current.style.transform = "translate(0, -160%)";
    }
  };
  return (
    <nav className="navbar">
      <div className="titleName">
        <Link href="/">
          Opsight
          <span className="green">.AI</span>
        </Link>
      </div>
      <div className="menuToggle">
        <input type="checkbox" onChange={toggleNav} />

        <span></span>
        <span></span>
        <span></span>
      </div>
      <div ref={navbarRef} className="linkMenu">
        <div className="links">
          <div className="navLink">
            <span>
              <Link href="/">Home</Link>
            </span>
            {/* <i className="fa-solid fa-chevron-down"></i> */}
            {/* <div className="linkOpen">
            <div className="subLinks">Vision</div>
            <div className="subLinks">Our mission statement</div>
            <div className="subLinks">Team Details</div>
          </div> */}
          </div>
          <div className="navLink">
            <span>
              <Link href="/about-us">About us</Link>
            </span>
            {/* <i className="fa-solid fa-chevron-down"></i> */}
            {/* <div className="linkOpen">
            <div className="subLinks">Vision</div>
            <div className="subLinks">Our mission statement</div>
            <div className="subLinks">Team Details</div>
          </div> */}
          </div>
          <div className="navLink">
            <span onClick={toggleLinks}>
              Solutions{" "}
              <i ref={chevronRef} className="fa-solid fa-chevron-down"></i>
            </span>
            <div
              className={`linkOpen ${
                isSublinksOpened ? "heightFull" : "heightZero"
              }`}
            >
              <div className="subLinks">
                <Link href="/performance_monitoring">
                  Performance Monitoring (OEE)
                </Link>
              </div>
              <div className="subLinks">
                <Link href="/predictive_analytics">Predictive Analytics</Link>
              </div>

              <div className="subLinks">
                <Link href="/customised_solutions">Customised Solutions</Link>
              </div>
            </div>
          </div>
          {/* <div className="navLink">
          <span>Products</span> <i className="fa-solid fa-chevron-down"></i>
          <div className="linkOpen">
            <div className="subLinks">IIOT Gateway</div>
            <div className="subLinks">Edge Computing Hardware</div>
          </div>
        </div> */}
          {/* <div className="navLink">
          <span>Resources</span>
        </div> */}

          <div className="navLink">
            <span>
              <Link href="/contact">Contact us</Link>
            </span>
          </div>
        </div>

        <div className="needHelp">
          <i className="fa-solid fa-envelope"></i>
          <div className="mailDetaials">
            <span> Any Query ?</span>
            <a href="mailto:connect@opsight.ai">connect@opsight.ai</a>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
