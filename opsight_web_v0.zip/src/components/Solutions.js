"use client";
import "./css/solutions.css";
import Image from "next/image";

import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";
import { useRef, useLayoutEffect } from "react";

const Solutions = (props) => {
  const { headImage, headImageMobile, contentImage, heading, desc, bullets } = props.data;

  const imageDiv = useRef(null);
  const imageDiv2 = useRef(null);

  const pointsDiv1 = useRef(null);
  const pointsDiv2 = useRef(null);
  const pointsDiv3 = useRef(null);

  const pointsDiv4 = useRef(null);
  const pointsDiv5 = useRef(null);
  const pointsDiv6 = useRef(null);
  const pointsDiv7 = useRef(null);

  const pointsArr = [pointsDiv4, pointsDiv5, pointsDiv6, pointsDiv7];

  useLayoutEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    // gsap.to(imageDiv.current, {
    //   width: "100%",
    //   opacity: 1,
    // });

    // gsap.to(imageDiv2.current, {
    //   scrollTrigger: {
    //     trigger: imageDiv2.current,
    //     start: "top center",
    //   },

    //   width: "100%",
    //   opacity: 1,
    // });

    const t1 = gsap.timeline();
    t1.to(pointsDiv1.current, {
      y: 0,
      opacity: 1,
      duration: 1,
      // ease: Power3.easeOut,
    })
      .to(
        pointsDiv2.current,
        {
          y: 0,
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      )
      .to(
        pointsDiv3.current,
        {
          y: 0,
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      )

    const t2 = gsap.timeline({
      scrollTrigger: {
        trigger: imageDiv2.current,
        start: "top center",
        // markers: true
      },
    });
    t2.to(imageDiv2.current, {
      opacity: 1,
      // width: "100%",
    }).to(pointsDiv4.current, {
      y: 0,
      opacity: 1,
      duration: 1,
      // ease: Power3.easeOut,
    })
      .to(
        pointsDiv5.current,
        {
          y: 0,
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      )
      .to(
        pointsDiv6.current,
        {
          y: 0,
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      ).to(
        pointsDiv7.current,
        {
          y: 0,
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      );

  }, []);
  return (
    <div className="solutionsSection pb-20">
      {/* <section className="second">
        <div id="second-sub">
          <p> {heading} </p>
          <h1>
            {desc[0]}
            <span> {desc[1]}</span>
          </h1>
        </div>
        <div className="bgdiv my-3 w-5/6">
          <div id="videodiv" className="h-[330px] w-1/2">
            <Image
              ref={imageDiv}
              className="w-0 opacity-0 h-[290px]"
              src={solutionImage1}
              width={900}
              height={0}
            />
          </div>
          <div id="checkdiv">
            <div
              ref={pointsDiv1}
              className="checkpoints -translate-y-10 opacity-0"
            >
              <i className="fas fa-check-circle"></i>
              <div className="content">
                <h4>{bullet1[0]}</h4>
                <p>{bullet1[1]}</p>
              </div>
            </div>
            <div
              ref={pointsDiv2}
              className="checkpoints -translate-y-10 opacity-0"
            >
              <i className="fas fa-check-circle"></i>
              <div className="content">
                <h4>{bullet2[0]}</h4>
                <p>{bullet2[1]}</p>
              </div>
            </div>
            <div
              ref={pointsDiv3}
              className="checkpoints -translate-y-10 opacity-0"
            >
              <i className="fas fa-check-circle"></i>
              <div className="content">
                <h4>{bullet3[0]}</h4>
                <p>{bullet3[1]}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bgdiv my-5 w-5/6">
          <div id="checkdiv">
            <div
              ref={pointsDiv4}
              className="checkpoints  -translate-y-10 opacity-0"
            >
              <i className="fas fa-check-circle"></i>
              <div className="content">
                <h4>{bullet4[0]}</h4>
                <p>{bullet4[1]}</p>
              </div>
            </div>
            <div
              ref={pointsDiv5}
              className="checkpoints -translate-y-10 opacity-0"
            >
              <i className="fas fa-check-circle"></i>
              <div className="content">
                <h4>{bullet5[0]}</h4>
                <p>{bullet5[1]}</p>
              </div>
            </div>
            <div
              ref={pointsDiv6}
              className="checkpoints -translate-y-10 opacity-0"
            >
              <i className="fas fa-check-circle"></i>
              <div className="content">
                <h4>{bullet6[0]}</h4>
                <p>{bullet6[1]}</p>
              </div>
            </div>
          </div>

          <div id="videodiv" className="h-[330px] w-1/2">
            <Image
              ref={imageDiv2}
              className="w-0 opacity-0 h-[290px]"
              src={solutionImage2}
              width={900}
              height={900}
            />
          </div>
        </div>
      </section> */}
      <div className="solutions_head">
        <Image src={headImage} width={900} height={500} className="solutions-image-laptop" />
        <Image src={headImageMobile} width={900} height={500} className="solutions-image-mobile" />
        <div ref={pointsDiv1} className="solutionsHeading checkpoints -translate-y-10 opacity-0">{heading}</div>
        <div ref={pointsDiv2} className="solutionsDesc checkpoints -translate-y-10 opacity-0">{desc}</div>
      </div>

      <h3 ref={pointsDiv3} className="checkpoints -translate-y-10 opacity-0">How does Opsight help in {heading}?</h3>
      <div className="contentGrid">
        <div className="contentLeft">
          {bullets.map((e, i) => {
            return (
              <div ref={pointsArr[i]} className="solutionsDiv checkpoints -translate-y-10 opacity-0">
                {" "}
                <i class={e.icon}></i> <h4>{e.heading}</h4> <p> {e.desc} </p>{" "}
              </div>
            );
          })}
        </div>
        <div ref={imageDiv2} className="contentRight opacity-0">
          <Image src={contentImage} height={900} width={900} />
        </div>
      </div>
    </div>
  );
};

export default Solutions;
