"use client";
import React, { useRef, useState } from "react";
import "./css/solutionEffect.css";
// import logo from "@/media/logo.jpg";
import Image from "next/image";

const SolutionEffect = () => {
  const toggleButton = useRef(null);

  const [sliderStyle, setSliderStyle] = useState({
    left: "2%",
    background: "#b22222",
    opacity: "1",
  });

  const [sliderHeading, setSetsliderHeading] = useState("Market Challenges");
  const [sliderDesc, setSetsliderDesc] = useState(
    "Challenges like Lack of Operations Insights, Low OEE, Higher Rejections, Unprecedented Downtime, and Delayed Decision Making impact companies and industries, causing inefficiency, increased costs, and reduced competitiveness."
  );

  const hadleToggleEffect = () => {
    //  console.log(toggleButton.current.checked);
    if (toggleButton.current.checked) {
      setSliderStyle({
        left: "48%",
        background: "rgb(41 111 105)",
      });
      setSetsliderHeading("Our Solutions");
      setSetsliderDesc(
        "Opsight.ai provides real-time insights, predictive maintenance, quality control, and decision support through advanced analytics and AI. By leveraging Opsight.ai's capabilities, companies can enhance operations, boost OEE, reduce rejections, minimize downtime, and streamline decision-making, ultimately ensuring greater efficiency and competitiveness in their industries."
      );
    } else {
      setSliderStyle({
        left: "2%",
        background: "#b22222",
        opacity: "1",
      });
      setSetsliderHeading("Market Challenges");
      setSetsliderDesc(
        "Challenges like Lack of Operations Insights, Low OEE, Higher Rejections, Unprecedented Downtime, and Delayed Decision Making impact companies and industries, causing inefficiency, increased costs, and reduced competitiveness."
      );
    }
  };

  return (
    <div className="solutionsContainer">
      <div className="divider"></div>
      <div className="effectsHeading">
        <div>Industry Challenges</div>
        <div>Our Offerings</div>
      </div>
      <div className="solutionEffectSection">
        {/* <div className="toggleDiv">
         <span className="toggleStart">Toggle</span>
         <span className="toggleEnd">to witness the Transformation!</span>
        </div> */}
        {/* <div className="toggleEffect">
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            value=""
            className="sr-only peer"
            ref={toggleButton}
            onClick={hadleToggleEffect}
          />

          <div className="w-11 h-6 bg-white-400 border peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-white-700 dark:peer-focus:ring-gray-200 rounded-full peer dark:bg-white-50 peer-checked:after:translate-x-full peer-checked:after:border-white-400 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-red-600 after:border-gray-100 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:after:bg-gray-600 bg-gray-300"></div>
        </label>
      </div> */}
        {/* <div className="effectsSlider" style={sliderStyle}>
        <div className="sub-heading">{sliderHeading}</div>
        <div className="challengesDescription">
          {sliderDesc}
        </div>
      </div> */}

        <div className="solution-right">
          <div className="beforeEffects effect1">
            Lack of Operational Insights
          </div>
          <div className="beforeEffects effect2">Low OEE</div>
          <div className="beforeEffects effect3">Higher Rejections</div>
          <div className="beforeEffects effect4">Unprecedented Downtime</div>
          <div className="beforeEffects effect5">Delayed Decision Making</div>
        </div>
        <div className="mid">
          <Image className="logo" src="/logo.jpg" width={500}
                    height={500} />
        </div>
        <div className="solution-left">
          <div className="effects effect1">Real-Time Production Insights</div>
          <div className="effects effect2">Higher OEE</div>
          <div className="effects effect3">Lower Rejections</div>
          <div className="effects effect4">Preventive Maintenance</div>
          <div className="effects effect5">Data-Driven Operations</div>
        </div>

        {/* <Image className="mygif" src={mygif} /> */}
      </div>
    </div>
  );
};

export default SolutionEffect;
