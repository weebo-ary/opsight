import "@/components/css/vision.css";
// import vision from "@/media/vision.jpg";
import Image from "next/image";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useLayoutEffect, useEffect, useState, useRef } from "react";
// import { SplitText } from "gsap-trial/SplitText";

const AboutVision = () => {
  const originalContent = useRef(null);
  const visContainer = useRef(null);
  const visHead = useRef(null);
  const iiot = useRef(null);
  const bd = useRef(null);
  const aiml = useRef(null);
  const visDes = useRef(null);
  const visImage = useRef(null);

  useLayoutEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    // gsap.registerPlugin(SplitText);

    // const text = new SplitText(originalContent.current, {
    //   type: "chars",
    // });

    // gsap.to(text.chars, {
    //   scrollTrigger: {
    //     trigger: originalContent.current,
    //     // scroller: "#main",
    //     start: "top 70%",
    //     end: "top 40%",
    //     scrub: true,
    //     // markers: true,
    //   },
    //   stagger: 0.1,
    //   // opacity: 1,
    //   // scale: 2,
    //   delay: 0.5,
    //   color: "#021d41",
    // });

    gsap.to(visImage.current, {
      scrollTrigger: {
        trigger: visContainer.current,
        toggleActions: "restart none none reset",

        start: "top 60%",
        end: "top 20%",
        // markers: true,
        // scrub: 5.5,
        smooth: true,
      },
      y: "10px",
      opacity: 1,
      duration: 1.5,
    });

    var t1 = gsap.timeline({
      scrollTrigger: {
        trigger: visContainer.current,
        toggleActions: "restart none none reset",

        start: "top 60%",
        end: "top 20%",
        // markers: true,
        // scrub: 5.5,
        smooth: true,
      },
    });

    t1.to(originalContent.current, {
      y: "10px",
      opacity: 1,
      duration: 1,
      color: "#021d41"
    }).to(visHead.current, {
      y: "10px",
      opacity: 1,
      duration: 1,
    }).to(
        iiot.current,
        {
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      ).to(
        bd.current,
        {
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      )
      .to(
        aiml.current,
        {
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      )
      .to(
        visDes.current,
        {
          y: "10px",
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      );
  }, []);

  return (
    <>
      <div className="visionContainer" id="vision">
        <div ref={visContainer}>
          <div className="visionDiv">
            <h1
              ref={originalContent}
              className="text-gray-200 font-bold vision -translate-y-10 opacity-0"
            >
              Our Vision
            </h1>
            <h2 ref={visHead} className="-translate-y-10 opacity-0">
              Developing an affordable indigenous solutions for Indian
              manufacturers in critical emerging technologies like:
            </h2>
            <div className="mt-6">
              <div className="badges">
                <a
                  ref={iiot}
                  href="#"
                  className="bg-blue-100 font-semibold mr-2 px-2.5 py-0.5 rounded bg-gray-700 text-white border  inline-flex items-center justify-center opacity-0"
                >
                  IIOT
                </a>
                <a
                  ref={bd}
                  href="#"
                  className="bg-blue-100 font-semibold mr-2 px-2.5 py-0.5 rounded bg-gray-700 text-white border  inline-flex items-center justify-center opacity-0"
                >
                  Big Data Analytics
                </a>
                <a
                  ref={aiml}
                  href="#"
                  className="bg-blue-100 font-semibold mr-2 px-2.5 py-0.5 rounded bg-gray-700 text-white border inline-flex items-center justify-center opacity-0"
                >
                  AI/ML
                </a>
              </div>
              <h2 ref={visDes} className="-translate-y-10 opacity-0">
                enabling them to produce globally-competitive goods within India
                and shift towards data-driven operations.
              </h2>
            </div>
          </div>

          <div className="imageDiv">
            <Image
              ref={visImage}
              className="translate-y-36 opacity-0 rounded-2xl"
              src={"/ourVision.svg"}
              width={600}
              height={300}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default AboutVision;
