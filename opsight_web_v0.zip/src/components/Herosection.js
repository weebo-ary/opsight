import React from "react";
import Image from "next/image";
import "./css/hero-section.css";
import Link from "next/link";
// import dashboard_laptop from "../media/dashboard_laptop.png"

const Herosection = () => {
  return (
    <div className="main-section">
      <div className="heading">
        <h1>
          Opsight<span className="green">.AI</span>
        </h1>
        <h2>
          Transforming <span className="greens">Op</span>erations Data Into
          Actionable In<span className="greens">sight</span>s!
        </h2>
      </div>
      <div className="sub-heading">
        <h3>
          Enabling companies to unlock their untapped manufacturing potential &
          achieve operational excellence through AI.
        </h3>
      </div>
      <div className="buttons">
        <Link href="/about-us">
          <button className="btn-green">
            <h1>Learn More</h1>
            <i className="fa-solid fa-up-right-from-square"></i>
          </button>
        </Link>
        {/* <button className="green-outline">
            <Link href="/about-us">
              <h1>Who are we </h1>
            </Link>
            <i className="fa-solid fa-chevron-right"></i>
          </button> */}
      </div>
    </div>
  );
};

export default Herosection;
