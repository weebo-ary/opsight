import React, { useState } from "react";
import "./css/counter.css";
import CountUp from "react-countup";
import ScrollTrigger from "react-scroll-trigger";

const NumberCounter = () => {
  const [counterState, setCounterState] = useState(false);
  return (
    <>
      <div className="counter-up">
        <ScrollTrigger
          className="w-full"
          onEnter={() => setCounterState(true)}
          onExit={() => setCounterState(false)}
        >
          <div className="content">
            <div className="box">
              <div className="icon">
                <i className="fas fa-history"></i>
              </div>
              <div className="counter">
                {counterState && (
                  <CountUp start={0} end={95} duration={2.75}>
                    95
                  </CountUp>
                )}
                %
              </div>
              <div className="text">Success Rate</div>
            </div>
            <div className="box">
              <div className="icon">
                <i className="fas fa-gift"></i>
              </div>
              <div className="counter">
                {counterState && (
                  <CountUp start={0} end={508} duration={2.75}>
                    508
                  </CountUp>
                )}
              </div>
              <div className="text">Completed Projects</div>
            </div>
            <div className="box">
              <div className="icon">
                <i className="fas fa-users"></i>
              </div>
              <div className="counter">
                {counterState && (
                  <CountUp start={0} end={436} duration={2.75}>
                    436
                  </CountUp>
                )}
              </div>
              <div className="text">Happy Clients</div>
            </div>
            <div className="box">
              <div className="icon">
                <i className="fas fa-award"></i>
              </div>
              <div className="counter">
                {counterState && (
                  <CountUp start={0} end={120} duration={2.75}>
                    120
                  </CountUp>
                )}
              </div>
              <div className="text">Awards Received</div>
            </div>
          </div>
        </ScrollTrigger>
      </div>
    </>
  );
};

export default NumberCounter;
