import Card from "./Card";
import "./css/ourProducts.css";
import Image from "next/image";
// import perMon from "@/media/Monitoring.png";
// import Analysis from "@/media/Analysis.png";
// import design from "@/media/design.png";

import gsap from "gsap"
import {ScrollTrigger} from "gsap/ScrollTrigger"
import {useLayoutEffect, useRef} from "react"

const OurProducts = () => {

  const headingDiv = useRef(null)
  const div1 = useRef(null)
  const div2 = useRef(null)
  const div3 = useRef(null)

  useLayoutEffect(() => {
    
    gsap.registerPlugin(ScrollTrigger);

    const t1 = gsap.timeline({
      scrollTrigger: {
        trigger: headingDiv.current,
        toggleActions: "restart none none reset",
        start: "top 70%",
        end: "top 40%",
        // markers: true,
      },
    })

    t1.to(div1.current, {
      y: 0,
        opacity:1,
        duration: 1,
    })
    .to(div2.current, {
      y: 0,
        opacity: 1,
        duration: 1,
    }, "-=0.5")
    .to(div3.current, {
      y: 0,
        opacity: 1,
        duration: 1,
    }, "-=0.5")    
  
    
  }, [])

  const cardsDetails = [
    {
      name: "Performance Monitoring (OEE)",
      desc: "OEE performance monitoring enhances industrial efficiency.",
      cardImg: "/Monitoring_home1.png",
      icon: "chart-pie",
      link: "/performance_monitoring",
    },
    {
      name: "Predictive Analytics",
      desc: "Continuous Monitoring and Immediate Data Analysis for Real-time Insights.",
      cardImg: "/analytics_home.jpg",
      icon: "chart-line",
      link: "/predictive_analytics",
    },
    {
      name: "Customised Solutions",
      desc: "Tailored solutions for your specific needs.",
      cardImg: "/solutions_home.jpg",
      icon: "server",
      link: "/customised_solutions",
    },
  ];

  return (
    <div ref={headingDiv} className="productsSection">
      <Image src="/wave.svg" height={300} width={700} className="producsWave"/>
      <div ref={div1} className="procutsHead translate-y-5 opacity-0 ">Our Solutions</div>
      <div ref={div2} className="productsDesc translate-y-5 opacity-0">
        Coupled with our machine monitoring technology, our solutions pave the
        way for data-driven decision-making, predictive maintenance, and
        enhanced operational excellence.
      </div>
      <div ref={div3} className="solutionsGrid translate-y-5 opacity-0">
        {cardsDetails.map((e, i) => {
          return <Card key={i} item={e} />;
        })}
      </div>
    </div>
  );
};

export default OurProducts;
