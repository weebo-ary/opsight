import "@/components/css/vision.css";
// import vision from "@/media/vision.jpg";
import Image from "next/image";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useLayoutEffect, useEffect, useState, useRef } from "react";
// import { SplitText } from "gsap-trial/SplitText";

const AboutMission = () => {
  const originalContent = useRef(null);
  const visContainer = useRef(null);
  const visHead = useRef(null);
  const iiot = useRef(null);
  const bd = useRef(null);
  const aiml = useRef(null);
  const visDes = useRef(null);
  const visImage = useRef(null);

  useLayoutEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    // gsap.registerPlugin(SplitText);

    // const text = new SplitText(originalContent.current, {
    //   type: "chars",
    // });

    

    // gsap.to(text.chars, {
    //   scrollTrigger: {
    //     trigger: originalContent.current,
    //     // scroller: "#main",
    //     start: "top 70%",
    //     end: "top 40%",
    //     scrub: true,
    //     // markers: true,
    //   },
    //   stagger: 0.1,
    //   // opacity: 1,
    //   // scale: 2,
    //   delay: 0.5,
    //   color: "#021d41",
    // });

    gsap.to(visImage.current, {
      scrollTrigger: {
        trigger: visContainer.current,
        toggleActions: "restart none none reset",

        start: "top 60%",
        end: "top 20%",
        // markers: true,
        // scrub: 5.5,
        smooth: true,
      },
      y: "10px",
      opacity: 1,
      duration: 1.5,
    });

    var t1 = gsap.timeline({
      scrollTrigger: {
        trigger: visContainer.current,
        toggleActions: "restart none none reset",

        start: "top 60%",
        end: "top 20%",
        // markers: true,
        // scrub: 5.5,
        smooth: true,
      },
    });

    t1.to(originalContent.current, {
      y: "10px",
      opacity: 1,
      duration: 1,
      color: "#021d41"
    }).to(visHead.current, {
      y: "10px",
      opacity: 1,
      duration: 1,
    })
      .to(
        iiot.current,
        {
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      )
      .to(
        bd.current,
        {
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      )
      .to(
        aiml.current,
        {
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      )
      .to(
        visDes.current,
        {
          y: "10px",
          opacity: 1,
          duration: 1,
        },
        "-=0.6"
      );
  }, []);

  return (
    <>
      <div id="mission" className="missionContainer">
        <div
          ref={visContainer}
        >
          <div className="imageDiv">
            <Image
              ref={visImage}
              className="translate-y-36 opacity-0 rounded-2xl"
              src={"/ourMission.jpg"}
              width={600}
              height={300}
            />
          </div>

          <div className="relative flex flex-col missionDiv">
            <h1
              ref={originalContent}
              className="text-gray-200 font-bold vision"
            >
              Our Mision
            </h1>
            <h2
              ref={visHead}
              className="-translate-y-10 opacity-0"
            >
              To empower manufacturers to leverage the power of AI and machine
              learning by delivering Real-time Production Insights &amp;
              Predictive Analytics for optimising their Productivity, Equipment
              Downtime &amp; Rework Costs.
            </h2>
          </div>
        </div>
      </div>
    </>
  );
};

export default AboutMission;
